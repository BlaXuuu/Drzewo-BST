var searchData=
[
  ['remove_0',['remove',['../class_b_s_t.html#a51af554dc558ec500d4a05ade218afa3',1,'BST']]]
];
