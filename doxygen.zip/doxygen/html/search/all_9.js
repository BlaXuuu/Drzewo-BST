var searchData=
[
  ['savetobinary_0',['saveToBinary',['../class_file_handler.html#aa47f12fd1234d495150878713a096ca7',1,'FileHandler']]],
  ['savetotext_1',['saveToText',['../class_file_handler.html#adf899f61ee8db594aab6a8c710e9e4e3',1,'FileHandler']]]
];
