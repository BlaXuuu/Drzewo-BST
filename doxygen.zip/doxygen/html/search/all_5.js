var searchData=
[
  ['loadfrombinary_0',['loadFromBinary',['../class_file_handler.html#a5b8b6663304c446c120efc673670babb',1,'FileHandler']]],
  ['loadfromtext_1',['loadFromText',['../class_file_handler.html#a70751f065b033a82404bf9afc64a3f6c',1,'FileHandler']]]
];
