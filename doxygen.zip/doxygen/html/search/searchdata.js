var indexSectionsWithContent =
{
  0: "bcdfilmprs~",
  1: "bf",
  2: "bfm",
  3: "bcdfilmprs~",
  4: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Przyjaciele"
};

