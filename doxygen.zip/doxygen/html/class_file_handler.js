var class_file_handler =
[
    [ "loadFromBinary", "class_file_handler.html#a5b8b6663304c446c120efc673670babb", null ],
    [ "loadFromText", "class_file_handler.html#a70751f065b033a82404bf9afc64a3f6c", null ],
    [ "saveToBinary", "class_file_handler.html#aa47f12fd1234d495150878713a096ca7", null ],
    [ "saveToText", "class_file_handler.html#adf899f61ee8db594aab6a8c710e9e4e3", null ]
];