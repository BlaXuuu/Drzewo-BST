var dir_7c4e5f4bd95ab7a518d47afcb0b1bdaa =
[
    [ "Drzewo-BST-master", "dir_1d44e93c75fc4b31d7b07ad334df0717.html", "dir_1d44e93c75fc4b31d7b07ad334df0717" ]
];